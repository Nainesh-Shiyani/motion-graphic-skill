/* bg: liquid - WebGL flowing "liquid metal / silk" gradient built from --mk-c1..3 (AI, SaaS, creative).
 * Reacts softly to the cursor. Falls back to aurora when WebGL is unavailable.
 * Options: data-bg-speed="1" data-bg-scale="1.6" (bigger = busier pattern), --mk-liquid-opacity */
(function (MK) {
  'use strict';
  MK.shaderBg('liquid', {
    maxDpr: 0.75,
    uniforms: { u_scale: function (env) { return env.opt('scale', 1.6); } },
    fs: [
      'uniform float u_scale;',
      'void main(){',
      '  vec2 uv=gl_FragCoord.xy/u_res;',
      '  vec2 p=uv*vec2(u_res.x/u_res.y,1.)*u_scale;',
      '  float t=u_time*.06;',
      '  vec2 m=(u_mouse-.5)*.6*(.4+u_hover);',
      '  vec2 q=vec2(fbm(p+t),fbm(p+vec2(5.2,1.3)-t));',
      '  vec2 r=vec2(fbm(p+3.*q+vec2(1.7,9.2)+t*1.6+m),fbm(p+3.*q+vec2(8.3,2.8)-t*1.2-m));',
      '  float f=fbm(p+2.6*r);',
      '  vec3 col=mix(u_c1,u_c2,smoothstep(.15,.85,f));',
      '  col=mix(col,u_c3,smoothstep(.35,1.,length(r)*.85));',
      '  col*=.72+.5*f;',
      '  gl_FragColor=vec4(col,1.);',
      '}'
    ].join('\n')
  });
})(window.MotionKit);
